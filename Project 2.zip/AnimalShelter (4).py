from pymongo import MongoClient
from bson.objectid import ObjectId
import json
from bson.json_util import dumps

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self,username=None, password=None):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        if username and password:
            self.client = MongoClient('mongodb://%s:%s@localhost:48557' % (username, password))
        else:
            self.client = MongoClient('mongodb://localhost:48557')
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert(data)  # data should be dictionary  
            if insert!= 0:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD. 
    def read(self,search):
        
            
        data = self.database.animals.find(search,{"_id":False})
       
     

        return data
#Create method to implement the U in CRUD
    def update(self, save, data):
        if save and data is not None:
            updateData={"$set": data}
            updated = self.database.animals.find_one_and_update(save,updateData)
        
        else:
            raise Exception("Nothing to update")
        return updated
#Create method to implement to D in CRUD
    def delete(self, data):
        if data is not None:
            deleted = self.database.animals.delete_one(data)
            
        else:
            raise Exception("Nothing to delete")
        return deleted